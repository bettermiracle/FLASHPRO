package com.better.flashpro

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var cameraManager: CameraManager
    private var cameraId: String? = null
    private var isTorchOn = false

    private lateinit var torchButton: TextView
    private lateinit var statusText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        torchButton = findViewById(R.id.torchButton)
        statusText = findViewById(R.id.statusText)

        cameraManager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
        cameraId = findFlashCamera()

        if (cameraId == null) {
            torchButton.isEnabled = false
            statusText.text = "This phone has no supported torch"
            return
        }

        torchButton.setOnClickListener { setTorch(!isTorchOn) }

        findViewById<TextView>(R.id.subscribeButton).setOnClickListener {
            Toast.makeText(
                this,
                "Premium checkout will be connected here.",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun findFlashCamera(): String? {
        return cameraManager.cameraIdList.firstOrNull { id ->
            val characteristics = cameraManager.getCameraCharacteristics(id)
            characteristics.get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    }

    private fun setTorch(on: Boolean) {
        val id = cameraId ?: return
        try {
            cameraManager.setTorchMode(id, on)
            isTorchOn = on
            torchButton.text = if (on) "OFF" else "ON"
            statusText.text = if (on) "Torch is ON" else "Torch is OFF"
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to control the torch.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onStop() {
        super.onStop()
        if (isTorchOn) setTorch(false)
    }
}
